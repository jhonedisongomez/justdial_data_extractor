from django.apps import AppConfig


class CrawlerManagerConfig(AppConfig):
    name = 'crawler_manager'
